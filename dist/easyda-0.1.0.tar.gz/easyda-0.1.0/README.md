# EasyDa: Simplified Data Analysis Library

EasyDa is a Python library that simplifies data analysis by combining the most common functionalities of pandas, matplotlib, and scikit-learn with a simplified interface for quick analysis.
